const message = () => {
    const name = "Jan";
    const age = "67";
    return "imię: " + name + ", ile lat? " + age;
};


export default message;