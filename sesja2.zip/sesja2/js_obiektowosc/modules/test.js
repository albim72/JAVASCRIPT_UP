import {
    name,
    age
} from "./person";

import message from './message';