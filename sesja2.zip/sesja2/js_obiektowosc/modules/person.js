const name = "Henryk";
const age = 40;

export { name, age }